﻿// lr7 ex1.cpp
/* Описать класс с двумя полями: число элементов одномерного массива и указатель на динамический одномерный массив (предусмотреть корректное выделение памяти).
Описать для этого класса:
- перегруженный конструктор копирования;
- перегрузить операцию «=» (присвоение, исключить возможность самоприсваивания);
- описать дружественную классу перегруженную операцию «<<» вывода элементов массива. */

#include <iostream>
using namespace std;

class Massiv
{
	int* Arr;
	int N;
public:
	Massiv() { Arr = 0; N = 0; }

	Massiv(int N)
	{
		this->N = N;

		Arr = new int[N]; //выделения памяти под массив
		cout << "Массив создан\n";

		for (int i = 0; i < N; i++) //заполнения массива нулями
			Arr[i] = 0;

		Add(Arr, N);
		Show();
	}

	void Add(int* Arr, const int N) //заполнения массива значениями
	{
		cout << "\nЗаполните массив числами\n";
		for (int i = 0; i < N; i++)
			cin >> Arr[i];
	}

	void Show() //отображения массива на экране
	{
		cout << "\nВывод массива\n";
		for (int i = 0; i < N; i++)
			cout << Arr[i] << "  ";
		cout << endl << endl;
	}

	~Massiv()
	{
		delete[]Arr;
	}

	Massiv(Massiv& obj) //конструктор копирования
	{
		cout << "Конструктор копирования\n";
		Arr = new int[obj.N];
		N = obj.N;

		for (int i = 0; i < N; i++)
			Arr[i] = obj.Arr[i];

		Show();
	}

	Massiv& operator=(Massiv& obj) //перегруженная операция =
	{
		N = obj.N;

		Arr = new int[N];
		for (int i = 0; i < N; i++)
			Arr[i] = obj.Arr[i];

		return *this;
	}

	friend ostream& operator<<(ostream& out, Massiv& obj); //перегрузка <<
};

ostream& operator<<(ostream& out, Massiv& obj) //перегруженная операция <<
{
	cout << "Перегруженная операция вывода массива\n";
	for (int i = 0; i < obj.N; i++)
	{
		out << obj.Arr[i] << "  ";
	}
	cout << endl;

	return out;
}

int main()
{
	setlocale(LC_ALL, "Ru");

	int N = 0;
	cout << "Введите размер массива N = ";
	cin >> N; cout << endl;

	Massiv A(N);
	cout << A << endl;

	Massiv B(A);

	Massiv C(N);
	cout << "Массив после присвоения\n";
	C = A;
	cout << C << endl;

	return 0;
}