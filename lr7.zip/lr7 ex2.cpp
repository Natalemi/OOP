﻿// lr7 ex2.cpp
// Для класса двумерного массива перегрузить операцию «+».

#include <iostream>
using namespace std;

class Matrix
{
	int** Arr;
	int row, col;
public:
	Matrix()
	{
		row = col = 0;
		Arr = NULL;
	}

	Matrix(int row, int col)
	{
		this->row = row;
		this->col = col;
		this->Arr = new int*[row]; // выделения памяти под массив

		for (int i = 0; i < row; i++) // перераспределяем выделенную память
			Arr[i] = new int[col]; // количество столбцов

		for (int i = 0; i < row; i++)
			for (int j = 0; j < col; j++)
				Arr[i][j] = 0;
	}

	void Add(int row, int col)
	{
		for (int i = 0; i < row; i++)
			for (int j = 0; j < col; j++)
				Arr[i][j] = rand() % 10;
	}

	void Print()
	{
		for (int i = 0; i < row; i++) {
			for (int j = 0; j < col; j++) {
				cout << Arr[i][j] << " ";
			}
			cout << endl;
		}
	}

	Matrix operator +(const Matrix& obj)
	{
		if (this->row == obj.row && this->col == obj.col)
		{
			Matrix temp(this->row, this->col);
			for (int i = 0; i < this->row; i++) {
				for (int j = 0; j < this->col; j++) {
					temp.Arr[i][j] = this->Arr[i][j] + obj.Arr[i][j];
					cout << temp.Arr[i][j] << " ";
				}
				cout << endl;
			}
			return temp;
		}
		else
		{
			cout << "Ошибка\n";
		}
	}

	~Matrix()
	{
		for (int i = 0; i < row; i++) {
			delete Arr[i];
		}
		delete[] Arr;

		Arr = NULL;
	}
};

int main()
{
	setlocale(LC_ALL, "Ru");

	int row = 3;
	int col = 3;
	Matrix A(row, col);
	cout << "Заполнение матрицы A\n"; A.Add(row, col); A.Print();
	Matrix B(row, col);
	cout << "\nЗаполнение матрицы B\n"; B.Add(row, col); B.Print();
	
	cout << "\nA + B\n";
	Matrix C = A + B;
	C.Print();

	return 0;
}