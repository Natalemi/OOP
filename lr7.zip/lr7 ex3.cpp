﻿// lr7 ex3.cpp
/* Перегрузить операцию присваивания и вывода для индивидуального варианта класса.
10. Программист:
- фамилия;
- число программ, написанных программистом;
- число языков программирования, которыми он пишет программы. */

#include <iostream>
#include <string>
using namespace std;

class Programmer
{
protected:
    string surname; int number_programs; int number_languages; double Q;
public:
    Programmer() { string surname = ""; int number_programs = 0; int number_languages = 0; }

    Programmer(string _surname, int _number_programs, int _number_languages)
    {
        surname = _surname;
        number_programs = _number_programs;
        number_languages = _number_languages;
    }

    string Get_surname() { return surname; }
    int Get_number_programs() { return number_programs; }
    int Get_number_languages() { return number_languages; }

    double Get_Q() { return Q; }

    void Set_surname(string surname) { this->surname = surname; cin >> surname; }
    void Set_number_programs(int number_programs) { this->number_programs = number_programs; cin >> number_programs; }
    void Set_number_languages(int number_languages) { this->number_languages = number_languages; cin >> number_languages; }

    void qualityQ() { Q = number_programs * number_languages; }

    friend ostream& operator<<(ostream& out, Programmer& f); //перегруженная операция <<
    friend istream& operator>>(istream& is, Programmer& prog);

    Programmer& operator=(const Programmer& obj) //перегруженная операция =
    {
        this->surname = obj.surname;
        this->number_programs = obj.number_programs;
        this->number_languages = obj.number_languages;
        
        return *this;
    }

    ~Programmer() {}
};

ostream& operator<<(ostream& out, Programmer& prog) //перегруженная операция <<
{
    cout << "Перегруженная операция вывода\n";
    out << "Фамилия программиста - " << prog.Get_surname() << "\nЧисло программ, написанных программистом = " << prog.Get_number_programs() << "\nЧисло языков программирования, которыми он пишет программы = " << prog.Get_number_languages() << "\nКачество = " << prog.Get_Q() << "\n";

    return out;
}

istream& operator>>(istream& is, Programmer& prog)
{
    is >> prog.surname >> prog.number_programs >> prog.number_languages;
    
    return is;
}

int main()
{
    setlocale(LC_ALL, "Ru");

    Programmer third;

    cin >> third;
    third.qualityQ();
    cout << third << endl;

    Programmer third2 = third;
    cout << third2 << endl;

    system("pause");
    return 0;
}