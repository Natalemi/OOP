﻿// lr4 ex3.cpp Агрегация и композиция классов
/* Переделать класс из ex2 таким образом, чтобы два вектора создавались глобально (как глобальные переменные)
и передавались конструктору как параметры («агрегация»).
В комментарии сделать вывод о разнице между композицией и агрегацией. */

#include <iostream>
#include <cmath>
using namespace std;

class Vector
{
    double x, y, z;
public:
    Vector() { x = 0; y = 0; z = 0; }

    Vector(double _x, double _y, double _z) { x = _x; y = _y; z = _z; }

    double Get_x() { return x; }

    double Get_y() { return y; }

    double Get_z() { return z; }

    void Set_Point(double x_start, double y_start, double z_start, double x_end, double y_end, double z_end)
    {
        x = x_end - x_start;
        y = y_end - y_start;
        z = z_end - z_start;
    }

	~Vector() {}
};

class Operations : public Vector
{
public:
    static Vector Composition_Vectors(Vector AB, Vector BC) // сложение векторов
    {
        return Vector((AB.Get_x() + BC.Get_x()), (AB.Get_y() + BC.Get_y()), (AB.Get_z() + BC.Get_z()));
    }

    static Vector Subtraction_Vectors(Vector AB, Vector BC) // вычитание векторов
    {
        return Vector((AB.Get_x() - BC.Get_x()), (AB.Get_y() - BC.Get_y()), (AB.Get_z() - BC.Get_z()));
    }

    static double Scalar_Product(Vector AB, Vector BC) // скалярное произведение векторов
    {
        return (AB.Get_x() * BC.Get_x() + AB.Get_y() * BC.Get_y() + AB.Get_z() * BC.Get_z());
    }

    static Vector Vector_Product(Vector AB, Vector BC) // векторное произведение векторов
    {
        return Vector(AB.Get_y() * BC.Get_z() - AB.Get_z() * BC.Get_y(), -(AB.Get_x() * BC.Get_z() - AB.Get_z() * BC.Get_x()), AB.Get_x() * BC.Get_y() - AB.Get_y() * BC.Get_x());
    }
};

int main()
{
    setlocale(LC_ALL, "Ru");
    Vector AB;
    Vector BC;
    Vector Composition;
    Vector Subtraction;
    Vector Product;
    
    AB.Set_Point(1, 4, 2, 5, 3, 6);
    cout << "Вектор AB(" << AB.Get_x() << ", " << AB.Get_y() << ", " << AB.Get_z() << ")\n";
    BC.Set_Point(5, 3, 6, 7, 6, 8);
    cout << "Вектор BC(" << BC.Get_x() << ", " << BC.Get_y() << ", " << BC.Get_z() << ")\n";
    
    Composition = Operations::Composition_Vectors(AB, BC);
    cout << "\nСумма векторов AB и BC(" << Composition.Get_x() << ", " << Composition.Get_y() << ", " << Composition.Get_z() << ")\n";

    Subtraction = Operations::Subtraction_Vectors(AB, BC);
    cout << "Разность векторов AB и BC(" << Subtraction.Get_x() << ", " << Subtraction.Get_y() << ", " << Subtraction.Get_z() << ")\n";

    cout << "Скалярное произведение векторов AB и BC = " << Operations::Scalar_Product(AB, BC);

    Product = Operations::Vector_Product(AB, BC);
    cout << "\nВекторное произведение векторов AB и BC(" << Product.Get_x() << ", " << Product.Get_y() << ", " << Product.Get_z() << ")\n";

	system("pause");
	return 0;
}