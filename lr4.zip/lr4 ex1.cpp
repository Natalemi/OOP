﻿// lr4 ex1.cpp Агрегация и композиция классов
/* Описать класс для хранения координат вектора в трехмерном пространстве.
Предусмотреть все необходимые конструкторы, уровни доступа, методы доступа и т.д. */

#include <iostream>
using namespace std;

class Vector
{
private:
	double x;
	double y;
	double z;
public:
    Vector() { x = 0; y = 0; z = 0; }

    Vector(double _x, double _y, double _z) { x = _x; y = _y; z = _z; }

    double Get_x() { return x; }

    double Get_y() { return y; }

    double Get_z() { return z; }

    void Set_Point_A_B(double x_start, double y_start, double z_start, double x_end, double y_end, double z_end)
    {
        x = x_end - x_start;
        y = y_end - y_start;
        z = z_end - z_start;
    }

    void Print()
    {
        cout << "Vector AB(" << Get_x() << ", " << Get_y() << ", " << Get_z() << ")\n";
    }

	~Vector() {}
};

int main()
{
    Vector AB;
    AB.Set_Point_A_B(1, 4, 2, 5, 3, 6);
    AB.Print();

	system("pause");
	return 0;
}