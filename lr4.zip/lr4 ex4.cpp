﻿// lr4 ex4.cpp Агрегация и композиция классов
/* Реализовать класс для выполнения операций сложения и вычитания над двумя векторами в N-мерном пространстве.
Способ описания ассоциации классов (композиция или агрегация) выбрать самостоятельно.
Указания:
- N задавать как защищенное поле;
- учитывать изменения N в связанных конструкторах;
- вектор задавать двумя точками, для этого ввести также класс для описания точки;
- класс для сложения векторов должен задавать размерность вектора, исходя из этого необходимо корректно создавать точки и векторы;
Всё обосновать в комментариях! */

#include <iostream>
#include <cmath>
using namespace std;

class Operations : public Vector {
    private:
    public:
        //static Vector AB;
        //static Vector BC;
        static float lenghtOfVector(Vector Vector){
            /* Функция, для подсчета длинны одного вектора */
            return (sqrt(std::pow(Vector.getX(), 2) + std::pow(Vector.getY(), 2) + std::pow(Vector.getZ(), 2)));
        }

        static Vector CompositionOfVectors(Vector AB, Vector BC) {
            /* Сложение векторов в трехмерном пространстве */
            return Vector((AB.getX() + BC.getX()), (AB.getY() + BC.getY()),
                          (AB.getZ() + BC.getZ()));
        }
        static Vector SubstractionOfVectors(Vector AB, Vector BC) {
            /* Вычитание векторов в трехмерном пространстве */
            return Vector((AB.getX() - BC.getX()), (AB.getY() - BC.getY()),
                          (AB.getZ() - BC.getZ()));
        }
        static float scalarProduct(Vector AB, Vector BC){
            /*Скалярное произведение векторов, 2-ая формула*/
            return (AB.getX() * BC.getX()+ AB.getY() * BC.getY() + AB.getZ() * BC.getZ());
        }

        static float cosinus(Vector AB, Vector BC){
            /* Подсчет косинуса между двумя векторами */
            return ((scalarProduct(AB, BC))/(lenghtOfVector(AB) * lenghtOfVector(BC)));
        }

        static float innerProduct(Vector AB, Vector BC) {
            /*Скалярное произведение векторов, 2-ая формула*/
            return lenghtOfVector(AB) * lenghtOfVector(BC) * cosinus(AB, BC);
        }


        static Vector vectorProduct(Vector AB, Vector BC){
            /*Векторное произведение векторов в трехмерном пространсвте*/
            return Vector(AB.getY() * BC.getZ() - AB.getZ() * BC.getY(),
                          -(AB.getX() * BC.getZ() - AB.getZ() * BC.getX()),
                          AB.getX() * BC.getY() - AB.getY() * BC.getX());
        }
};

int main()
{
    setlocale(LC_ALL, "Ru");

    polyVector AB(2);
    polyVector BC(2);
    cout << AB.getCoordinates();
    cout << BC.getCoordinates();

    polyVector composition;
    composition = polyVector::compositionObject(AB, BC);
    composition.writeNumbersComposition(AB, BC, composition);
    cout << composition.getCoordinates() << " ";
    cout << endl;
    AB.setCoordinates(2001, 2);
    cout << AB.getCoordinates();
    
    system("pause");
    return 0;
}