﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Создать программу для тестирования. Варианты вопросов:
- множественный выбор, единственный ответ;
- множественный выбор, множественный ответ;
- ввод слова;
- на соответствие. */

namespace lr11_ex1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int balls = 0;
            if (radioButton2.Checked == true)
                balls = balls + 1;
            
            if (checkBox1.Checked == true && checkBox2.Checked == true && checkBox3.Checked == true && checkBox5.Checked == true)
                balls = balls + 1;

            if (textBox1.Text == "Ханбок" || textBox1.Text == "ханбок" && textBox2.Text == "38")
                balls = balls + 1;

            if (textBox5.Text == "г" && textBox6.Text == "б" && textBox7.Text == "а")
                balls = balls + 1;

            label13.Text = "Количество набранных баллов: " + Convert.ToString(balls);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}