﻿// lr6 ex2.cpp
/* Построить класс-потомок класса из ex1, который содержит:
- дополнительное поле P;
- функция, которая определяет «качество» объекта класса - Qp,
которая перекрывает функцию качества класса родительского уровня (Q),
выполняя вычисление по новой формуле (столб 3).

10. Q = (число программ)*(число языков)
 P: число программ, которые работают правильно.
 Qp = Q · Р / (число всех программ) */

#include <iostream>
#include <string>
using namespace std;

class Programmer
{
protected:
    string surname; int number_programs; int number_languages; double Q;
public:
    Programmer() { string surname = ""; int number_programs = 0; int number_languages = 0; }

    Programmer(string _surname, int _number_programs, int _number_languages)
    {
        surname = _surname;
        number_programs = _number_programs;
        number_languages = _number_languages;
    }

    string Get_surname() { return surname; }

    int Get_number_programs() { return number_programs; }

    int Get_number_languages() { return number_languages; }

    double Get_Q() { return Q; }

    virtual void qualityQ()
    {
        Q = number_programs * number_languages;
    }

    void Print()
    {
        cout << "Фамилия программиста - " << Get_surname() << "\nЧисло программ, написанных программистом = " << Get_number_programs() << "\nЧисло языков программирования, которыми он пишет программы = " << Get_number_languages() << "\nКачество = " << Get_Q() << "\n\n";
    }

    ~Programmer() {}
};

class Descendant : public Programmer
{
    int P;
public:
    Descendant() { P = 0; }

    Descendant(string _surname, int _number_programs, int _number_languages, int _P)
    {
        surname = _surname;
        number_programs = _number_programs;
        number_languages = _number_languages;
        P = _P;
    }

    double Get_P() { return P; }

    void qualityQ() override
    {
        Q = (number_programs * number_languages * P) / number_programs;
    }

    ~Descendant() {}
};

int main()
{
    setlocale(LC_ALL, "Ru");

    Programmer first("Иванов", 45, 3);
    first.qualityQ();
    first.Print();

    Descendant first1("Иванов", 45, 3, 42);
    first1.qualityQ();
    first1.Print();

    system("pause");
    return 0;
}