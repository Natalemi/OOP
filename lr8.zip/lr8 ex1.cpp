﻿// lr8 ex1.cpp
/* Создать шаблон класса для работы с массивом произвольного типа данных. 
Шаблон должен включать:
- указатель, хранящий адрес размещения массива в динамической памяти;
- целочисленную переменную, показывающую количество занятых элементов массива;
- конструктор без параметров, с параметрами, по умолчанию;
- конструктор копирования;
- деструктор;
- другие методы. */

#include <iostream>
using namespace std;

template <typename T>
class Array
{
    T* array;
    int size;
public:
    Array() { throw runtime_error("You must pass an array of any data."); }

    Array(T* array, int size) { this->array = array; this->size = size; }

    void show()
    {
        for (int i = 0; i < size; i++) { cout << array[i] << endl; }
    }

    void showFromEnd()
    {
        for (int i = size-1; i >= 0; i--) { cout << array[i] << endl; }
    }

    void sortArray()
    {
        for (int i = 0; i < size - 1; i++) {
            for (int j = 0; j < size - i - 1; j++) {
                if (array[j] > array[j + 1]) {
                    auto temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }

    Array(const Array& Other)
    {
        this->size = Other.size;
        this->array = new T[Other.size];
        cout << "\nКонструктор копирования\n";
        for (int i = 0; i < size; i++)
            this->array[i] = Other.array[i];
    }

    ~Array() { delete[] array; }
};

float generateFloatNumber(double a, double b)
{
    return ((b - a) * ((double)rand() / RAND_MAX)) + a;
}

void callObject(Array<int> example)
{
    cout << "Call object\n";
}

int main()
{
    setlocale(LC_ALL, "Ru");
    int N = 6;
    auto* arr1 = new float[N];
    for (int i = 0; i < N; i++)
        arr1[i] = generateFloatNumber(0, 5);

    cout << "Пример массива с вещественными числами\n";
    Array<float> obj1(arr1, N);
    obj1.show();
    obj1.sortArray(); cout << "\nСортировка массива по возрастанию\n";
    obj1.show();

    auto* arr2 = new int[N];
    for (int i = 0; i < N; i++)
        arr2[i] = generateFloatNumber(0, 5);

    cout << "\nПример массива с целыми числами\n";
    Array<int> obj2(arr2, N);
    obj2.show();
    obj2.sortArray(); cout << "\nСортировка массива по возрастанию\n";
    obj2.show();

    cout << "\nВывод массива в обратном порядке\n";
    obj2.showFromEnd();

    callObject(obj2);
}